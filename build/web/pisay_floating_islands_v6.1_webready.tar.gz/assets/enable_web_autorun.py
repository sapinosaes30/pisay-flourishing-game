from pathlib import Path


index_path = Path(__file__).resolve().parent / "build" / "web" / "index.html"
if not index_path.is_file():
    raise FileNotFoundError(f"Web build index not found: {index_path}")

html = index_path.read_text(encoding="utf-8")
default = "autorun : 0,"
if html.count(default) != 1:
    raise RuntimeError("Expected exactly one pygbag autorun setting set to 0.")

index_path.write_text(html.replace(default, "autorun : 1,", 1), encoding="utf-8")
